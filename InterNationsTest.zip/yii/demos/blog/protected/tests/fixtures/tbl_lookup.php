<?php

return array(
	/*
	'sample1'=>array(
		'name' => '',
		'code' => '',
		'type' => '',
		'position' => '',
	),
	'sample2'=>array(
		'name' => '',
		'code' => '',
		'type' => '',
		'position' => '',
	),
	*/
);
