<?php

class TagTest extends CDbTestCase
{
	public $fixtures=array(
		'tags'=>'Tag',
	);

	public function testCreate()
	{

	}
}